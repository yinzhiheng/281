This set of sample files includes the following:

spec-simple.txt                - From the project specification, page 2
spec-complex.txt               - From the project specification, page 3
appendix-a.txt                 - From the Project specification, Appendix A
larger-simple.txt              - A larger simple dictionary, ~ 4300 words
larger-simple-sample-runs.txt  - Output for several different word morphs
larger-complex.txt             - A larger complex dictionary, ~ 4300 words
larger-complex-sample-runs.txt - Output for several different word morphs
